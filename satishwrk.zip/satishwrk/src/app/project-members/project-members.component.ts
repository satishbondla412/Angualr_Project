import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-project-members',
  templateUrl: './project-members.component.html',
  styleUrls: ['./project-members.component.scss']
})
export class projectMembersComponent implements OnInit {

  taskDeatilsForm: FormGroup;
  taskDeatils;

  constructor(
    private fb: FormBuilder,
    private router: Router
  ) { }

  ngOnInit() {
  
  }



  save() {
    
  }

}