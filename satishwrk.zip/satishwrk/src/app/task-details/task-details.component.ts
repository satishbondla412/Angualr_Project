import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-task-details',
  templateUrl: './task-details.component.html',
  styleUrls: ['./task-details.component.scss']
})
export class TasksDetailsComponent implements OnInit {

  taskDeatilsForm: FormGroup;
  taskDeatils;
  assignees;
  taskStatuses;
  isFromCreate = false;
  submitted = false;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if(params['from'] == 'fromCreate') {
        this.isFromCreate = true;
      } else {
        this.isFromCreate = false;
      }
     
    });
    this.assignees = [{id:1, name: 'kumar'},{id:2, name: 'satish'},{id:3, name: 'bharath'}];
    this.taskStatuses = [{id:1, status: 'In progress'},{id:2, status: 'Completed'},{id:3, status: 'Pending'}];
    this.taskDeatils = {
      description: 'Create New PAge',
      assignee: 1,
      storyPoints : '5',
      taskStatuses : 1
    }
    this.taskDeatilsForm = this.fb.group({
      description: [this.isFromCreate? '': this.taskDeatils.description ? this.taskDeatils.description : '', Validators.required],
      assignee: [this.isFromCreate? '':this.taskDeatils.assignee ? this.taskDeatils.assignee : '', Validators.required],
      storyPoints: [this.isFromCreate? '':this.taskDeatils.storyPoints ? this.taskDeatils.storyPoints : '', Validators.required],
      taskStatus: [this.isFromCreate? '':this.taskDeatils.taskStatuses ? this.taskDeatils.taskStatuses : '', Validators.required]
    });
  }


  // convenience getter for easy access to form fields
  get tasksForm() { return this.taskDeatilsForm.controls; }

  assigneeChange(e){

  }

  taskStatusChange(e) {
    
  }

  cancel() {
    this.router.navigate([`tasks`]);
  }

  save() {
    
  }

}