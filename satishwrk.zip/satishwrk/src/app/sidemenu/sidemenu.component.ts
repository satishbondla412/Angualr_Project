
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.scss']
})
export class SidemenuComponent implements OnInit {
  events: string[] = [];
  opened: boolean; isMobileView = false;
  appDrawer: any;
  currentEnvironment: any;
  showClients: boolean;
  showFoods= false;
  constructor(private route: Router) {
  }

  ngOnInit() {
    this.currentEnvironment = environment;
    const innerWidth = window.innerWidth;
    if (innerWidth < 768) {
      this.isMobileView = true;
    }
  }

  close(reason: string) {
  }

  logout() {
  }

  clickToNavigate(routeLink: any, from?) {
    if (from == 'profile') {
  
    }
    if (this.isMobileView) {
    } else {
    }
  }

}
