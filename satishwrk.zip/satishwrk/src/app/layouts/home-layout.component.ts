import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-layout',
  templateUrl: './home-layout.component.html',
  styleUrls: ['./home-layout.component.scss']
})
export class HomeLayoutComponent implements OnInit{

  innerWidth: any;
  opened: boolean;
  isMobileView = false;
  modeType: string;
  logImageUrl: string;


  constructor() { }

  ngOnInit() {
    this.innerWidth = window.innerWidth;
    if (this.innerWidth > 767) {
      this.opened = true;
      this.modeType = 'side';
    } else {
      this.opened = false;
      this.isMobileView = true;
      this.modeType = 'over';
    }
  }

  onUserClick() {
    //this.router.navigate([`clients/1/profile`]);
  }

  closeMenu() {
    return false;
  }

  closeMenuOnBackDropClick() {
    if (this.isMobileView) {
      // this.globalState.appDrawer.toggle();
    }
  }
}