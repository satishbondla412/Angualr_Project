import { Router } from '@angular/router';
import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.scss']
})
export class TasksComponent {

  constructor(private router: Router) {}

  goToDetailePage() {
   this.router.navigate([`task-details`]);
  }
  createNewTask(from){
    this.router.navigate([`task-details`], {queryParams : {from: from}});
  }
}