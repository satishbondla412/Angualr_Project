import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from './../auth/auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegisterFormComponent implements OnInit {
  registrationForm: FormGroup;
  private formSubmitAttempt: boolean;
  loading = false;
  submitted = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
    this.registrationForm = this.fb.group({
      userName: ['', Validators.required],
      password: ['', Validators.required],
      confirmpPassword: ['', Validators.required],
      email: ['', Validators.required]
    });
  }

  isFieldInvalid(field: string) {
    return (
      (!this.registrationForm.get(field).valid && this.registrationForm.get(field).touched) ||
      (this.registrationForm.get(field).untouched && this.formSubmitAttempt)
    );
  }

  // convenience getter for easy access to form fields
  get registerForm() { return this.registrationForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.registrationForm.valid) {
      this.authService.login(this.registrationForm.value);
    }
    this.formSubmitAttempt = true;
  }

  cancel(){
    this.router.navigate([`login`]);
  }
  createProfile(){

  }
}
