import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.scss']
})
export class ManageUsersComponent implements OnInit {

  taskDeatilsForm: FormGroup;
  taskDeatils;

  constructor(
    private fb: FormBuilder,
    private router: Router
  ) { }

  ngOnInit() {
  
  }

  save() {
    
  }

}